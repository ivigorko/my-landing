// Site-wide configuration
export interface SiteConfig {
  language: string;
  siteName: string;
  siteDescription: string;
}

export const siteConfig: SiteConfig = {
  language: "ru",
  siteName: "Деревенские бани",
  siteDescription: "Традиционная русская баня в Симферополе на берегу озера. Дровяная печь, дубовые веники, искусство банщика.",
};

// Hero Section
export interface HeroConfig {
  backgroundImage: string;
  backgroundAlt: string;
  title: string;
  subtitle: string;
}

export const heroConfig: HeroConfig = {
  backgroundImage: "/banya-master.jpg",
  backgroundAlt: "Традиционная русская баня с банщиком и веником",
  title: "Деревенские бани: где оживает легенда русского парения",
  subtitle: "Традиции, проверенные веками. Огонь дровяной печи. Дух дубового веника. Искусство банщика — в Симферополе, на берегу озера",
};

// Narrative Text Section - "Легенда о трех силах"
export interface NarrativeTextConfig {
  line1: string;
  line2: string;
  line3: string;
}

export const narrativeTextConfig: NarrativeTextConfig = {
  line1: "Легенда о трех силах",
  line2: "Три столпа русской банной культуры",
  line3: "Пар — дыхание жизни. Веник — лекарь и массажист. Контраст — закалка духа. Веками эти три силы исцеляли тело и очищали душу русского человека.",
};

// ZigZag Grid Section - "Банщик — хранитель легенды" и практические блоки
export interface ZigZagGridItem {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  imageAlt: string;
  reverse: boolean;
}

export interface ZigZagGridConfig {
  sectionLabel: string;
  sectionTitle: string;
  items: ZigZagGridItem[];
}

export const zigZagGridConfig: ZigZagGridConfig = {
  sectionLabel: "Искусство парения",
  sectionTitle: "Банщик — хранитель легенды",
  items: [
    {
      id: "bath-master",
      title: "Проводник в мир глубокого расслабления",
      subtitle: "Мастерство передаётся из поколения в поколение",
      description: "Настоящая русская баня немыслима без банщика. Это не просто парильщик — это проводник в мир глубокого расслабления. Наши банщики знают: какой веник выбрать для вашего типа кожи, как правильно распарить спину, когда сделать передышку. Умение парить — ремесло, передающееся из поколения в поколение. Закажите веничание у банщика — почувствуйте разницу между просто «парилкой» и настоящим русским парением.",
      image: "/banya-master.jpg",
      imageAlt: "Банщик с дубовым веником в русской бане",
      reverse: false,
    },
    {
      id: "rest-zone",
      title: "Зона отдыха — завершение ритуала",
      subtitle: "После парилки — на лавочку",
      description: "Традиция отдыха с травяным чаем и медом — неотъемлемая часть банного ритуала. В нашей зоне отдыха вы сможете расслабиться, восстановить силы и насладиться тишиной. Подайте травяной чай с мятой, эвкалиптом или полынью — каждая трава несёт свою пользу и гармонию.",
      image: "/samovar-tea.jpg",
      imageAlt: "Традиционный русский самовар с травяным чаем",
      reverse: true,
    },
    {
      id: "certificates",
      title: "Подарить легенду",
      subtitle: "День рождения и подарочные сертификаты",
      description: "Подарить легенду — лучше любого материального подарка. Подарочный сертификат в «Деревенские бани» — это приглашение прикоснуться к живой традиции, подарить здоровье и расслабление. Идеальный подарок для близких, друзей и коллег.",
      image: "/venik-oak.jpg",
      imageAlt: "Дубовый веник — символ русской бани",
      reverse: false,
    },
    {
      id: "restaurant",
      title: "Традиционная банная кухня",
      subtitle: "Доставка из ресторана",
      description: "Отварное мясо, соленья, травяные чаи — настоящая банная кухня дополняет ритуал парения. Мы предлагаем доставку блюд традиционной русской кухни прямо в баню. Всё, что нужно для полного погружения в атмосферу деревенского отдыха.",
      image: "/herbal-tea.jpg",
      imageAlt: "Травяные настои и банная кухня",
      reverse: true,
    },
  ],
};

// Breath Section - "Приходите за легендой"
export interface BreathSectionConfig {
  backgroundImage: string;
  backgroundAlt: string;
  title: string;
  subtitle: string;
  description: string;
}

export const breathSectionConfig: BreathSectionConfig = {
  backgroundImage: "/lake-cabin.jpg",
  backgroundAlt: "Деревенская баня на берегу озера",
  title: "Приходите за легендой",
  subtitle: "Живая традиция в Симферополе",
  description: "Мы не просто предлагаем «попариться». Мы приглашаем вас прикоснуться к живой традиции, которая делала русских людей сильными, здоровыми и долговечными. В наших банях горит тот же огонь, что и сто лет назад. Тот же пар. Та же сила.",
};

// Card Stack Section - "Традиции, которые мы храним"
export interface CardStackItem {
  id: number;
  image: string;
  title: string;
  description: string;
  rotation: number;
}

export interface CardStackConfig {
  sectionTitle: string;
  sectionSubtitle: string;
  cards: CardStackItem[];
}

export const cardStackConfig: CardStackConfig = {
  sectionTitle: "Традиции, которые мы храним",
  sectionSubtitle: "Культурные акценты русской бани",
  cards: [
    {
      id: 1,
      image: "/venik-wall.jpg",
      title: "Баня венком",
      description: "Ритуал веничания от парильщика — услуга, которую можно заказать. Дубовый веник в руках мастера становится инструментом глубокого расслабления и исцеления.",
      rotation: -2,
    },
    {
      id: 2,
      image: "/banya-interior.jpg",
      title: "Три подхода",
      description: "Классическая схема парения: первый — разогреться, второй — попариться, третий — закалиться. Каждый подход имеет свою цель и технику.",
      rotation: 1,
    },
    {
      id: 3,
      image: "/herbal-tea.jpg",
      title: "Банная запарка",
      description: "Травяные настои для веников: мята освежает, эвкалипт очищает дыхание, полынь согревает. Каждая трава — своя сила.",
      rotation: -1,
    },
  ],
};

// Footer Section
export interface FooterContactItem {
  type: "email" | "phone";
  label: string;
  value: string;
  href: string;
}

export interface FooterSocialItem {
  platform: string;
  href: string;
}

export interface FooterConfig {
  heading: string;
  description: string;
  ctaText: string;
  contact: FooterContactItem[];
  locationLabel: string;
  address: string[];
  socialLabel: string;
  socials: FooterSocialItem[];
  logoText: string;
  copyright: string;
  links: { label: string; href: string }[];
}

export const footerConfig: FooterConfig = {
  heading: "Запишитесь в баню",
  description: "Почувствуйте силу русской банной традиции. Звоните или пишите — мы расскажем о доступном времени и поможем выбрать оптимальную программу.",
  ctaText: "Заказать веничание",
  contact: [
    {
      type: "phone",
      label: "+7 (978) 000-00-00",
      value: "+79780000000",
      href: "tel:+79780000000",
    },
    {
      type: "email",
      label: "info@derevenskie-bani.ru",
      value: "info@derevenskie-bani.ru",
      href: "mailto:info@derevenskie-bani.ru",
    },
  ],
  locationLabel: "Адрес",
  address: ["г. Симферополь", "На берегу озера", "Республика Крым"],
  socialLabel: "Мы в соцсетях",
  socials: [
    {
      platform: "instagram",
      href: "https://instagram.com/derevenskie_bani",
    },
    {
      platform: "facebook",
      href: "https://facebook.com/derevenskie_bani",
    },
  ],
  logoText: "Деревенские бани",
  copyright: "© 2025 Деревенские бани. Все права защищены.",
  links: [
    { label: "Политика конфиденциальности", href: "#" },
    { label: "Условия использования", href: "#" },
  ],
};
